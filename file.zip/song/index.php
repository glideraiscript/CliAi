<?php
Header("Location: https://www.clivio.biz");
exit();
?>
