   // CONFIG
    const JSON_PATH = './mp3_list.json';
    const GET_TRACK_URL = './get_track_url.php'; // endpoint che restituisce expires e token
    const STREAMER = './stream.php'; // fallback
    const COVER_DIR = './thumbs/';
    const BATCH_SIZE = 40;
    const PRELOAD_AHEAD = 3;

    // STATO
    let allEntries = [];
    let filtered = [];
    let offset = 0;
    let loading = false;
    let currentEntry = null;
    let currentEntryCard = null;
    let favorites = new Set(JSON.parse(localStorage.getItem('favorites')||'[]'));
    const dbName = 'AiSongCacheDB';
    const storeName = 'lista_mp3';

    // ELEMENTI
    const gallery = document.getElementById('gallery');
    const loadingEl = document.getElementById('loading');
    const searchInput = document.getElementById('search');
    const audio = document.getElementById('audio');
    const playPauseBtn = document.getElementById('play-pause');
    const stopBtn = document.getElementById('stop');
    const progress = document.getElementById('progress');
    const currentTimeEl = document.getElementById('current-time');
    const totalTimeEl = document.getElementById('total-time');
    const volumeSlider = document.getElementById('volume');
    const playerBox = document.getElementById('player-box');
    const playerTitle = document.getElementById('player-title');
    const playerDuration = document.getElementById('player-duration');
    const playerCover = document.getElementById('player-cover');
    const favoriteStatus = document.getElementById('favorite-status');

    let progressUpdater;
    let preloadPool = {};

	// Funzione per mischiare array (algoritmo Fisher-Yates)
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}
    // UTILI
    function fmtTime(sec){
      sec = Math.floor(sec);
      const m = Math.floor(sec/60);
      const s = sec%60;
      return m + ':' + (s<10?'0':'') + s;
    }

    // IndexedDB helper
    function openDB(){
      return new Promise((res, rej)=>{
        const req = indexedDB.open(dbName, 1);
        req.onupgradeneeded = e=>{
          const db = e.target.result;
          if (!db.objectStoreNames.contains(storeName)){
            db.createObjectStore(storeName);
          }
        };
        req.onsuccess = ()=>res(req.result);
        req.onerror = ()=>rej(req.error);
      });
    }
    async function getCachedList(){
      try {
        const db = await openDB();
        return new Promise((res, rej)=>{
          const tx = db.transaction(storeName,'readonly');
          const store = tx.objectStore(storeName);
          const r = store.get('lista');
          r.onsuccess = ()=>res(r.result);
          r.onerror = ()=>rej(r.error);
        });
      } catch(e){ return null; }
    }
    async function setCachedList(val){
      try {
        const db = await openDB();
        return new Promise((res, rej)=>{
          const tx = db.transaction(storeName,'readwrite');
          const store = tx.objectStore(storeName);
          const r = store.put(val,'lista');
          r.onsuccess = ()=>res();
          r.onerror = ()=>rej(r.error);
        });
      } catch(e){/* ignore */}
    }

 // Caricamento lista (prima da cache, poi da server)
async function fetchList(){
  loadingEl.textContent = 'Caricamento...';

  let cached = await getCachedList();
  if (cached){
    allEntries = Object.entries(cached).map(([k,v])=>({name:k,duration:v}));
    shuffleArray(allEntries); // 🔀 Mischia da cache
  }

  // Fetch dal server comunque per aggiornamento
  try {
    const resp = await fetch(JSON_PATH, {cache:'no-store'});
    if (!resp.ok) throw new Error('Impossibile caricare JSON');
    const obj = await resp.json();

    allEntries = Object.entries(obj).map(([k,v])=>({name:k,duration:v}));
    shuffleArray(allEntries); // 🔀 Mischia da fetch

    await setCachedList(obj);
  } catch(e){
    if (!allEntries.length){
      loadingEl.textContent = 'Errore caricamento lista: '+e.message;
      return;
    }
  }

  filtered = allEntries;
}

function naturalSort(a, b) {
  return a.name.localeCompare(b.name, 'it', {numeric: true, sensitivity: 'base'});
}

function applyFilter(term){
  if (!term){
    filtered = [...allEntries];
  } else {
    const lower = term.toLowerCase();
    filtered = allEntries.filter(el => el.name.toLowerCase().includes(lower));
  }

  // Ordina con natural sort
  filtered.sort(naturalSort);

  // Ripristina offset e galleria, poi carica i risultati
  offset = 0;
  gallery.innerHTML = '';
  loadMore();
}

    // Costruisci card
    function createCard(entry){
      const tpl = document.getElementById('card-template');
      const node = tpl.content.firstElementChild.cloneNode(true);
      const img = node.querySelector('.cover');
      const titleEl = node.querySelector('.title');
      const durationEl = node.querySelector('.duration');
      const favEl = node.querySelector('.favorite');

      titleEl.textContent = entry.name.replace(/\.mp3$/i,'');
      durationEl.textContent = entry.duration;
      img.src = COVER_DIR + entry.name.replace(/\.mp3$/i,'.jpg');
      img.alt = '' + titleEl.textContent;
	  img.title = '' + titleEl.textContent;
      if (favorites.has(entry.name)){
        favEl.textContent='★';
        favEl.classList.add('active');
      } else {
        favEl.textContent='☆';
      }

      favEl.addEventListener('click', e=>{
        e.stopPropagation();
        if (favorites.has(entry.name)){
          favorites.delete(entry.name);
          favEl.textContent='☆';
          favEl.classList.remove('active');
        } else {
          favorites.add(entry.name);
          favEl.textContent='★';
          favEl.classList.add('active');
        }
        localStorage.setItem('favorites', JSON.stringify([...favorites]));
        updateFavoriteStatusInPlayer();
      });

      node.addEventListener('click', ()=>playTrack(entry, node));
      return node;
    }

    // caricamento infinito
    async function loadMore(){
      if (loading) return;
      if (offset >= filtered.length){
        loadingEl.textContent='Fine della lista.';
        return;
      }
      loading = true;
      loadingEl.textContent='Caricamento...';
      const batch = filtered.slice(offset, offset + BATCH_SIZE);
      const frag = document.createDocumentFragment();
      batch.forEach(entry=>{
        const card = createCard(entry);
        frag.appendChild(card);
      });
      gallery.appendChild(frag);
      offset += batch.length;
      loading = false;
      loadingEl.textContent = offset >= filtered.length ? 'Tutto caricato.' : 'Scrolla per altro...';
    }

    function onScroll(){
      const scrollable = document.documentElement.scrollHeight - window.innerHeight;
      if (window.scrollY + 400 >= scrollable){
        loadMore();
      }
    }

    // Ottieni URL firmato
    async function getSignedUrl(filename){
      try {
        const params = new URLSearchParams({file: filename});
        const resp = await fetch(GET_TRACK_URL + '?' + params.toString());
        if (!resp.ok) throw new Error('Errore firmando');
        const json = await resp.json();
        if (json.error) throw new Error(json.error);
        return json.url; // url completo
      } catch(e){
        console.warn('Firma fallita, fallback semplice', e);
        // fallback non firmato (stream.php dovrà accettarlo)
        return `${STREAMER}?track=${btoa(filename)}`;
      }
    }

    // Precaricamento
    function preloadNext() {
      const list = filtered;
      if (!currentEntry) return;
      const idx = list.findIndex(e=>e.name===currentEntry.name);
      for (let i=1;i<=PRELOAD_AHEAD;i++){
        const next = list[idx + i];
        if (next && !preloadPool[next.name]){
          preloadPool[next.name] = new Audio();
          getSignedUrl(next.name).then(url=>{
            preloadPool[next.name].src = url;
            preloadPool[next.name].preload = 'auto';
          }).catch(()=>{/* ignore */});
        }
      }
    }

    // Player
    function showPlayer(entry, coverUrl){
      playerCover.src = coverUrl;
      playerTitle.textContent = entry.name.replace(/\.mp3$/i,'');
      playerDuration.textContent = entry.duration;
      updateFavoriteStatusInPlayer();
      playerBox.classList.add('active');
    }
    function hidePlayer(){
      playerBox.classList.remove('active');
      audio.pause();
      clearInterval(progressUpdater);
      playPauseBtn.textContent='▶️ Play';
      if (currentEntryCard) currentEntryCard.classList.remove('playing');
    }
    function updateFavoriteStatusInPlayer(){
      if (!currentEntry) return;
      const star = favorites.has(currentEntry.name)?'★':'☆';
      favoriteStatus.textContent = `⭐ Preferita: ${star} ${currentEntry.name.replace(/\.mp3$/i,'')}`;
    }

    async function playTrack(entry, cardNode){
      if (currentEntryCard && currentEntryCard !== cardNode){
        currentEntryCard.classList.remove('playing');
      }
      currentEntry = entry;
      if (currentEntryCard === cardNode && !audio.paused){
        audio.pause();
        playPauseBtn.textContent='▶️ Play';
        return;
      }
      currentEntryCard = cardNode;
      cardNode.classList.add('playing');

      showPlayer(entry, COVER_DIR + entry.name.replace(/\.mp3$/i,'.jpg'));

      const signed = await getSignedUrl(entry.name);
      audio.src = signed;
      audio.crossOrigin = "anonymous";
      try {
        await audio.play();
        playPauseBtn.textContent='⏸ Pause';
        audio.addEventListener('loadedmetadata', ()=>{
          totalTimeEl.textContent = fmtTime(audio.duration);
        });
        clearInterval(progressUpdater);
        progressUpdater = setInterval(()=>{
          if (audio.duration){
            const pct = (audio.currentTime / audio.duration) * 100;
            progress.value = pct;
            currentTimeEl.textContent = fmtTime(audio.currentTime);
          }
        },250);
        preloadNext();
      } catch(e){
        console.error('Play fallito', e);
      }
    }

    // Eventi
    playPauseBtn.addEventListener('click', ()=>{
      if (!currentEntry) return;
      if (audio.paused){
        audio.play();
        playPauseBtn.textContent='⏸ Pause';
      } else {
        audio.pause();
        playPauseBtn.textContent='▶️ Play';
      }
    });
    stopBtn.addEventListener('click', ()=>{
      audio.pause();
      audio.currentTime=0;
      playPauseBtn.textContent='▶️ Play';
    });
    progress.addEventListener('input', ()=>{
      if (audio.duration){
        audio.currentTime = (progress.value/100)*audio.duration;
      }
    });
    volumeSlider.addEventListener('input', ()=>{ audio.volume = volumeSlider.value; });
    document.getElementById('player-close').addEventListener('click', hidePlayer);
    window.addEventListener('keydown', e=>{ if (e.key==='Escape') hidePlayer(); });

    // Ricerca con debounce
    let debounceTimer;
    searchInput.addEventListener('input', e=>{
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(()=>{
        applyFilter(e.target.value.trim());
      }, 250);
    });

    // Init
    (async function(){
      await fetchList();
      if (allEntries.length===0) return;
      filtered = allEntries;
      await loadMore();
      window.addEventListener('scroll', onScroll, {passive:true});
    })();
	
	
	function getBaseTitles(entries) {
  const regex = /^(.*?)(\s*\d+)?\.mp3$/i;
  const titlesSet = new Set();

  entries.forEach(entry => {
    const match = entry.name.match(regex);
    if (match) {
      const baseTitle = match[1].trim();
      titlesSet.add(baseTitle);
    }
  });

  return Array.from(titlesSet).sort((a, b) => a.localeCompare(b, 'it', { sensitivity: 'base' }));
}

function buildSongMenu() {
  const menu = document.getElementById('songMenu');
  menu.innerHTML = ''; // Pulisci

  const titles = getBaseTitles(allEntries);
  titles.forEach(title => {
    const item = document.createElement('div');
    item.textContent = '🎙️ ' + title;
    item.style.cssText = 'padding: 4px 8px; cursor: pointer;';
    item.addEventListener('click', () => {
      applyFilter(title);
      menu.style.display = 'none';
    });
    item.addEventListener('mouseover', () => {
      item.style.background = '#f0f0f0';
    });
    item.addEventListener('mouseout', () => {
      item.style.background = 'transparent';
    });
    menu.appendChild(item);
  });
}

// Toggle del menu
document.getElementById('menuToggle').addEventListener('click', () => {
  const menu = document.getElementById('songMenu');
  if (menu.style.display === 'none' || !menu.style.display) {
    buildSongMenu();
    menu.style.display = 'block';
  } else {
    menu.style.display = 'none';
  }
});

// Chiudi il menu se clicchi fuori
document.addEventListener('click', (e) => {
  const menu = document.getElementById('songMenu');
  const toggle = document.getElementById('menuToggle');
  if (!menu.contains(e.target) && !toggle.contains(e.target)) {
    menu.style.display = 'none';
  }
});
