<?php

// your domain
$domain="https://www.clivio.biz";

// Site name\title
$title="Ai Song - By Clivio.Biz";

// Description for meta tag
$description="🦄 CliAi - Ai Song Gallery - by Clivio.Biz";

// cookie policy
$policy="
      Questo sito utilizza solo cookie tecnici essenziali per il funzionamento e la sicurezza della sessione.
<br>      Nessun dato dell’utente viene tracciato o condiviso.
<br>	  <br>
	  This site uses only essential technical cookies for session functionality and security.
<br>      No user data is tracked or shared.
";

// Set your key for protect the download of mpr
$key="YourKey";

// Set your api key from pollinations.ai
$token = "xxxxx-xxxxxxxxxx";

// Set domain referrer for generate cover
$AiPol="https://yoursite.com/";

?>